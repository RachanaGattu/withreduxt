import React from 'react';
//import logo from './logo.svg';
import './App.css';
import TransactionList from './components/TransactionList';

function App() {
  return (
    <TransactionList />
  );
}

export default App;
